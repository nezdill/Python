#Arnez Dillard 2339394
max = 5 #maximum number
total = 00.00 #Accumalator variable
print(max, "numbers you will enter.")


for test in range(max): #getting numbers and accumlating them
    scores = int(input("Enter test scores: "))
    average = total / scores
    

print("The average is ",average)
print()
