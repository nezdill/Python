#Arnez Dillard 2339394
for num in range(100, -1,-10):#loops that uses list of numbers backwards
    print(num, end=" ")#Displaying the numbers in a order
print("Its all done")#Displaying its done
