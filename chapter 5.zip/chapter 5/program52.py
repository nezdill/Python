#Arnez Dillard 2339394
#the random module
#calculations for random
import random
def main():
    for count in range(6):
        number = random.randint(1, 10)
        print(format(number, '4d'),end='') #displaying the random numbers
       
main()
