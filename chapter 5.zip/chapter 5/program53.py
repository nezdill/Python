#Arnez Dillard 2339394
#calculations for math
import math

def main():
    num = float(input("Enter a number: ")) #receiving first number

    num_two = float(input("Enter another number: ")) #receiving second dumber

    print("The total is: ", num + num_two) #displaying the total

    print("The different is: ", num - num_two) #displaying the differnce

    print("The product is: ", num * num_two) #displaying the product                       

    print("The quotient is: ", num / num_two) #displayng the quotient


main()

