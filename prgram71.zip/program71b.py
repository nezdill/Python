#Arnez Dillard 2339394

def main():
    #creat list of states
    states["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA"]
    print("Initial list of state abbreviations ")
    print('Reversed:',states)
    states.insert(2, "TX")

    print(Listby user)
    ptint(states)
main()
